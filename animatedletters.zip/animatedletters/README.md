# animatedletters

A Pen created on CodePen.io. Original URL: [https://codepen.io/elkrtn/pen/ZEmpGeM](https://codepen.io/elkrtn/pen/ZEmpGeM).

